const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton?.addEventListener('click', () => {
  const opened = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(opened));
  menuButton.textContent = opened ? '×' : '☰';
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
  if (menuButton) menuButton.textContent = '☰';
}));
if (new URLSearchParams(window.location.search).has('success')) {
  const result = document.querySelector('#formResult');
  if (result) {
    result.style.display = 'block';
    result.textContent = 'Спасибо! Форма отправлена. Если уведомления настроены, заявка поступит на электронную почту.';
    document.querySelector('#request')?.scrollIntoView({behavior:'smooth', block:'center'});
  }
}